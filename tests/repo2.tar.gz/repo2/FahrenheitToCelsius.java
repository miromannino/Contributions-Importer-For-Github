public class FahrenheitToCelsius {
    public static double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }

    public static void main(String[] args) {
        System.out.println(fahrenheitToCelsius(32)); // Output: 0.0
        System.out.println(fahrenheitToCelsius(68)); // Output: 20.0
    }
}

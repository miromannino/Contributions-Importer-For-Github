public class AddNumbers {
    public static int addNumbers(int num1, int num2) {
        return num1 + num2;
    }

    public static void main(String[] args) {
        int result = addNumbers(5, 7);
        System.out.println(result); // Output: 12
    }
}

function addNumbers(num1, num2) {
  return num1 + num2;
}
console.log(addNumbers(5, 7));
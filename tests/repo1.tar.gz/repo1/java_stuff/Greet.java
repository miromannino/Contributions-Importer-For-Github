public class Greet {
    public static String greet(String name) {
        return "Hello, " + name + "!";
    }

    public static void main(String[] args) {
        System.out.println(greet("Alice")); // Output: "Hello, Alice!"
    }
}

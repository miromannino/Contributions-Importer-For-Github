function containsSubstring(str, substring) {
  return str.includes(substring);
}
console.log(containsSubstring("JavaScript is fun", "fun")); // Output: true
console.log(containsSubstring("JavaScript is fun", "boring")); // Output: false
